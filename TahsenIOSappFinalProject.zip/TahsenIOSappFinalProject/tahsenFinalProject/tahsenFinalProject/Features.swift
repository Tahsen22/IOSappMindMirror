//
//  Features.swift
//  tahsenFinalProject
//
//  Created by Tahsen Shaon on 2022-03-08.
//

import UIKit

class Features: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func infoTable(_ sender: Any) {
        performSegue(withIdentifier: "infoTable", sender: nil)
    }
    
    @IBAction func note(_ sender: Any) {
        performSegue(withIdentifier: "note", sender: nil)
    }
    
    @IBAction func contact(_ sender: Any) {
        performSegue(withIdentifier: "contact", sender: nil)
    }
    
    @IBAction func cardGame(_ sender: Any) {
        performSegue(withIdentifier: "cardGame", sender: nil)
    }
}
