//
//  contact.swift
//  tahsenFinalProject
//
//  Created by Tahsen Shaon on 2022-03-11.
//

import UIKit
import MessageUI

class contact: UIViewController, MFMailComposeViewControllerDelegate {
    @IBOutlet weak var fullName: UITextField!
    @IBOutlet weak var message: UITextView!
    @IBOutlet weak var email: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    var phoneNumber = "4377766686"
    @IBAction func phoneCall(_ sender: Any) {
        if let phoneURL = URL(string: "tel://\(phoneNumber)") {
            let app:UIApplication = UIApplication.shared
            if app.canOpenURL(phoneURL) {
                app.open(phoneURL)
            }
        }
    }
    
    @IBAction func send(_ sender: Any) {
        var fullName = fullName.text
        var email = email.text
        var message = message.text
        if MFMailComposeViewController.canSendMail(){
            let mail = MFMailComposeViewController()
            mail.mailComposeDelegate = self
            mail.setToRecipients(["tahsen.rashed@gmail.com"])
            mail.setMessageBody("<p>The message is: \(message)</p><h4>user: \(fullName)</h4>", isHTML: true)
            present(mail,animated: true)
        } else {
            print("sending email in not available on simulator...")
        }
    }

}
